package fr.ldnr.dao;

import fr.ldnr.connection.MySQLConnection;
import java.sql.Connection;
import java.util.List;

public abstract class DAO<T> {

    protected Connection connection = MySQLConnection.getInstance();

    /**
     * Permet de récupérer un objet via son ID
     *
     * @param id
     * @return l’objet recherché
     */
    public abstract T find(Long id);

    /**
     * Permet de créer une entrée dans la base de données par rapport à un objet
     *
     * @param obj
     * @return l’objet créé avec son id
     */
    public abstract T create(T obj);

    /**
     * Permet de mettre à jour les données d'une entrée dans la base
     *
     * @param obj
     * @return l’objet modifié
     */
    public abstract T update(T obj);

    /**
     * Permet la suppression d'une entrée de la base
     *
     * @param obj
     */
    public abstract void delete(T obj);

    /**
     * Récupère toutes les données de la table
     *
     * @return Toutes les données sous forme de liste
     */
    public abstract List<T> list();
}
