package fr.ldnr.dao;

import fr.ldnr.beans.Utilisateur;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UtilisateurDAO extends DAO<Utilisateur> {

    private final String TABLE = "utilisateur";

    @Override
    public Utilisateur find(Long id) {
        Utilisateur utilisateur = null;
        try {
            String req = "SELECT * FROM " + TABLE + " WHERE id = ?";
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            pstmt.setLong(1, id);
            ResultSet result = pstmt.executeQuery();
            if (result.first()) {
                utilisateur = new Utilisateur(
                        id,
                        result.getString("email"),
                        result.getString("motdepasse"),
                        result.getString("nom")
                );
            }
        } catch (SQLException ex) {
            Logger.getLogger(UtilisateurDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return utilisateur;
    }

    @Override
    public Utilisateur create(Utilisateur obj) {
        try {
            String req = "INSERT INTO " + TABLE + " (email, motdepasse, nom) VALUES(?, ?, ?)";
            PreparedStatement pstmt = this.connection.prepareStatement(req, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, obj.getEmail());
            pstmt.setString(2, obj.getMotDePasse());
            pstmt.setString(3, obj.getNom());
            pstmt.executeUpdate();
            // Il faut ajouter l’identifiant à notre objet !
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.first()) { // Si on a des id créés
                obj.setId(rs.getLong(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UtilisateurDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }

    @Override
    public Utilisateur update(Utilisateur obj) {
        try {
            String req = "UPDATE " + TABLE + " SET email = ?, "
                    + "motdepasse = ?, nom = ?  WHERE id = ?";
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            pstmt.setString(1, obj.getEmail());
            pstmt.setString(2, obj.getMotDePasse());
            pstmt.setString(3, obj.getNom());
            pstmt.setLong(4, obj.getId());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(UtilisateurDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }

    @Override
    public void delete(Utilisateur obj) {
        try {
            String req = "DELETE FROM " + TABLE + " WHERE id = ?";
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            pstmt.setLong(1, obj.getId());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(UtilisateurDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Utilisateur> list() {
        List<Utilisateur> utilisateurs = new ArrayList<>();
        try {
            String req = "SELECT * FROM " + TABLE;
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            ResultSet result = pstmt.executeQuery();
            while (result.next()) {
                utilisateurs.add(new Utilisateur(
                        result.getLong("id"),
                        result.getString("email"),
                        result.getString("motdepasse"),
                        result.getString("nom")
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UtilisateurDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return utilisateurs;
    }

    public Utilisateur findByMail(String email) {
        Utilisateur utilisateur = null;
        try {
            String req = "SELECT * FROM " + TABLE + " WHERE email = ?";
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            pstmt.setString(1, email);
            ResultSet result = pstmt.executeQuery();
            if (result.first()) {
                utilisateur = new Utilisateur(
                        result.getLong("id"),
                        result.getString("email"),
                        result.getString("motdepasse"),
                        result.getString("nom")
                );
            }
        } catch (SQLException ex) {
            Logger.getLogger(UtilisateurDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return utilisateur;
    }
}
