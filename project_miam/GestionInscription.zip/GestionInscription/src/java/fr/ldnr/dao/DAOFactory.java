package fr.ldnr.dao;

public class DAOFactory {

    public static UtilisateurDAO getUtilisateurDAO() {
        return new UtilisateurDAO();
    }

    public static PostDAO getPostDAO() {
        return new PostDAO();
    }
}
