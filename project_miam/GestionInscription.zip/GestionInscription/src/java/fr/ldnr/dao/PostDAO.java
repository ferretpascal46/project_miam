package fr.ldnr.dao;

import fr.ldnr.beans.Post;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PostDAO extends DAO<Post> {

    private final String TABLE = "post";

    @Override
    public Post find(Long id) {
        Post post = null;
        try {
            String req = "SELECT * FROM " + TABLE + " WHERE id = ?";
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            pstmt.setLong(1, id);
            ResultSet result = pstmt.executeQuery();
            if (result.first()) {
                post = new Post(
                        id,
                        result.getLong("auteur"),
                        result.getString("titre"),
                        result.getString("contenu"),
                        result.getDate("dateCreation")
                );
            }
        } catch (SQLException ex) {
            Logger.getLogger(PostDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return post;
    }

    @Override
    public Post create(Post obj) {
        try {
            String req = "INSERT INTO " + TABLE + " (auteur, titre, contenu, dateCreation) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = this.connection.prepareStatement(req, Statement.RETURN_GENERATED_KEYS);
            pstmt.setLong(1, obj.getAuteur());
            pstmt.setString(2, obj.getTitre());
            pstmt.setString(3, obj.getContenu());
            pstmt.setDate(4, obj.getDateCreation());
            pstmt.executeUpdate();
            // Il faut ajouter l’identifiant à notre objet !
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.first()) { // Si on a des id créés
                obj.setId(rs.getLong(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PostDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }

    @Override
    public Post update(Post obj) {
        try {
            String req = "UPDATE " + TABLE + " SET auteur = ?, "
                    + "titre = ?, contenu = ?, dateCreation = ?  WHERE id = ?";
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            pstmt.setLong(1, obj.getAuteur());
            pstmt.setString(2, obj.getTitre());
            pstmt.setString(3, obj.getContenu());
            pstmt.setDate(4, obj.getDateCreation());
            pstmt.setLong(5, obj.getId());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PostDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }

    @Override
    public void delete(Post obj) {
        try {
            String req = "DELETE FROM " + TABLE + " WHERE id = ?";
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            pstmt.setLong(1, obj.getId());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PostDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Post> list() {
        List<Post> posts = new ArrayList<>();
        try {
            String req = "SELECT * FROM " + TABLE;
            PreparedStatement pstmt = this.connection.prepareStatement(req);
            ResultSet result = pstmt.executeQuery();
            while (result.next()) {
                posts.add(new Post(
                        result.getLong("id"),
                        result.getLong("auteur"),
                        result.getString("titre"),
                        result.getString("contenu"),
                        result.getDate("dateCreation")
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PostDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return posts;
    }
}
