package fr.ldnr.beans;

import java.io.Serializable;
import java.sql.Date;

/**
 *
 * @author Herbert
 */
public class Post implements Serializable {

    private static long serialVersionUID = 1L;

    private Long id;
    private long auteur;
    private String titre;
    private String contenu;
    private Date dateCreation;

    public Post() {
    }

    public Post(Long id, long auteur, String titre, String contenu, Date dateCreation) {
        this.id = id;
        this.auteur = auteur;
        this.titre = titre;
        this.contenu = contenu;
        this.dateCreation = dateCreation;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getAuteur() {
        return auteur;
    }

    public void setAuteur(long auteur) {
        this.auteur = auteur;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    @Override
    public String toString() {
        return "Post{" + "id=" + id + ", auteur=" + auteur + ", titre=" + titre + ", contenu=" + contenu + ", dateCreation=" + dateCreation + '}';
    }

}
