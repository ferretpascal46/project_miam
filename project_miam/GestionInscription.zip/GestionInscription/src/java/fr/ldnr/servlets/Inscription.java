package fr.ldnr.servlets;

import fr.ldnr.beans.Utilisateur;
import fr.ldnr.forms.InscriptionCheckForm;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Herbert
 */
@WebServlet(name = "Inscription", urlPatterns = {"/inscription"})
public class Inscription extends HttpServlet {

    /* Des constantes */
    public static final String VUE = "/WEB-INF/inscription.jsp";

    /**
     *
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        /* Affichage de la page d'inscription */
        this.getServletContext()
                .getRequestDispatcher(VUE)
                .forward(request, response);
    }

    /**
     *
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     *
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        /* Récupération des champs du formulaire forcés en UTF-8. */
        request.setCharacterEncoding("UTF-8");

        /* Préparation de l'objet formulaire */
        InscriptionCheckForm form = new InscriptionCheckForm();

        /*
         * Appel au traitement et à la validation de la requête, et récupération
         * du bean en résultant
         */
        Utilisateur utilisateur = form.checkForm(request);

        /*
         * Si l'inscription est validée, on entre l'utilisateur en session
         * et on le redirige vers la page d'accueil, sinon on réaffiche le
         * formulaire avec ses erreurs
         */
        if (form.getErreurs().isEmpty()) {
            request.getSession().setAttribute("sessionUtilisateur", utilisateur);
            response.sendRedirect(request.getContextPath() + "/index.jsp");
        } else {
            /* Stockage du formulaire et du bean dans l'objet request */
            request.setAttribute("form", form);
            request.setAttribute("utilisateur", utilisateur);

            /* Appel de la vue */
            this.getServletContext().getRequestDispatcher(VUE).forward(request, response);
        }
    }

    /**
     *
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Servlet d'inscription";
    }

}
