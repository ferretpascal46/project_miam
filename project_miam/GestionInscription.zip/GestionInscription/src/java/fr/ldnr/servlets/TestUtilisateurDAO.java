package fr.ldnr.servlets;

import fr.ldnr.dao.UtilisateurDAO;
import fr.ldnr.beans.Utilisateur;
import fr.ldnr.dao.DAOFactory;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "TestUtilisateurDAO", urlPatterns = {"/TestUtilisateurDAO"})
public class TestUtilisateurDAO extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Instanciation de notre DAO
        UtilisateurDAO udao = DAOFactory.getUtilisateurDAO();

        // Création de quelques personnes
        Utilisateur p1 = new Utilisateur(null, "admin@fai.tld", "admin", "chef");
        Utilisateur p2 = new Utilisateur(null, "alphonse.danlta@fai.fr", "123456", "Alf");
        // Affichage des personnes avant mise en DB
        System.out.println("-------------------------------------------");
        System.out.println("Affichage des personnes avant mise en DB");
        System.out.println("p1 = " + p1);
        System.out.println("p2 = " + p2);

        // Ajout en DB
        udao.create(p1);
        udao.create(p2);
        // Affichage des personnes après mise en DB => l'id est apparu !
        System.out.println("-------------------------------------------");
        System.out.println("Affichage des personnes après mise en DB");
        System.out.println("p1 = " + p1);
        System.out.println("p2 = " + p2);

        // Lecture de toutes les lignes de la DB
        System.out.println("-------------------------------------------");
        System.out.println("Lecture de toutes les lignes de la DB");
        for (Utilisateur p : udao.list()) {
            System.out.println("p = " + p);
        }

        // Modification de p2 et update en DB
        System.out.println("-------------------------------------------");
        System.out.println("Modification de p2 et update en DB");
        p2.setEmail("sophie.stule@fai.tld");
        p2.setMotDePasse("654321");
        p2.setNom("Sof");
        udao.update(p2);
        System.out.println("nouveau p2 : " + udao.find(p2.getId()));

        // Suppression de p2 dans la DB et affichage de toutes les personnes en DB
        System.out.println("-------------------------------------------");
        System.out.println("Suppression de p2 dans la DB et affichage de toutes les personnes en DB");
        udao.delete(p2);
        for (Utilisateur p : udao.list()) {
            System.out.println("p = " + p);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
