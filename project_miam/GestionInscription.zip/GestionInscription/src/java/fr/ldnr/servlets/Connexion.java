/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.ldnr.servlets;

import fr.ldnr.beans.Utilisateur;
import fr.ldnr.forms.ConnexionCheckForm;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Herbert
 */
@WebServlet(name = "Connexion", urlPatterns = {"/connexion"})
public class Connexion extends HttpServlet {

    private static final String VUE = "/WEB-INF/connexion.jsp";

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /* Affichage de la page de connexion */
        this.getServletContext().getRequestDispatcher(VUE).forward(request, response);
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /* Préparation de l'objet formulaire */
        ConnexionCheckForm form = new ConnexionCheckForm();

        /* Traitement de la requête et récupération du bean en résultant */
        Utilisateur utilisateur = form.checkForm(request);

        /* Récupération de la session depuis la requête */
        HttpSession session = request.getSession();

        /**
         * Si aucune erreur de validation n'a eu lieu, alors ajout du bean
         * Utilisateur à la session, sinon suppression du bean de la session.
         */
        if (form.getErreurs().isEmpty()) {
            session.setAttribute("sessionUtilisateur", utilisateur);
            response.sendRedirect(getServletContext().getContextPath() + "/index.jsp");
        } else {
            session.setAttribute("sessionUtilisateur", null);

            /* Stockage du formulaire et du bean dans l'objet request */
            request.setAttribute("form", form);
            request.setAttribute("utilisateur", utilisateur);

            this.getServletContext().getRequestDispatcher(VUE).forward(request, response);
        }
    }

}
