package fr.ldnr.forms;

/**
 *
 * @author Herbert
 */
import fr.ldnr.beans.Utilisateur;
import fr.ldnr.dao.DAOFactory;
import fr.ldnr.dao.UtilisateurDAO;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public final class ConnexionCheckForm {

    private String resultat;
    private Map<String, String> erreurs = new HashMap<>();

    public String getResultat() {
        return resultat;
    }

    public Map<String, String> getErreurs() {
        return erreurs;
    }

    public Utilisateur checkForm(HttpServletRequest request) {
        /* Récupération des champs du formulaire */
        String email = getValeurChamp(request, "email");
        String motDePasse = getValeurChamp(request, "motdepasse");

        Utilisateur utilisateur = new Utilisateur(null, email, motDePasse, null);

        /* Validation du champ email. */
        try {
            validationEmail(email);
        } catch (Exception e) {
            setErreur("email", e.getMessage());
        }

        /* Validation du champ mot de passe. */
        try {
            validationMotDePasse(motDePasse);
        } catch (Exception e) {
            setErreur("motdepasse", e.getMessage());
        }

        /* Initialisation du résultat global de la validation. */
        if (!erreurs.isEmpty()) { // Erreur dans les input
            resultat = "Échec de la connexion.";
            // On retourne l'utilisateur
            return utilisateur;
        }
        // Ici les input sont valides, on vérifie donc si l'utilisateur existe
        // avec ce mot de passe en DB
        Utilisateur utest = DAOFactory.getUtilisateurDAO().findByMail(utilisateur.getEmail());
        if (utest == null) { // Cet utilisateur n'existe pas
            setErreur("email", "Il n'y a pas d'utilisateur à ce nom.");
            return utilisateur;
        }
        if (!utest.getMotDePasse().equals(motDePasse)) { // mot de passe faux
            setErreur("motdepasse", "Le couple email/mot de passe n'est pas valide.");
            return utilisateur;
        } else { // Connexion confirmée
            resultat = "Succès de la connexion.";
            // On retourne l'utilisateur complet
            return utest;
        }
    }

    /**
     * Valide l'adresse email saisie.
     */
    private void validationEmail(String email) throws Exception {
        if (email == null) {
            throw new Exception("Merci de saisir une adresse mail.");
        } else if (!email.matches("([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)")) {
            throw new Exception("Merci de saisir une adresse mail valide.");
        }
    }

    /**
     * Valide le mot de passe saisi.
     */
    private void validationMotDePasse(String motDePasse) throws Exception {
        if (motDePasse != null) {
            if (motDePasse.length() < 3) {
                throw new Exception("Le mot de passe doit contenir au moins 3 caractères.");
            }
        } else {
            throw new Exception("Merci de saisir votre mot de passe.");
        }
    }

    /*
   * Ajoute un message correspondant au champ spécifié à la map des erreurs.
     */
    private void setErreur(String champ, String message) {
        erreurs.put(champ, message);
    }

    /*
   * Méthode utilitaire qui retourne null si un champ est vide, et son contenu
   * sinon.
     */
    private static String getValeurChamp(HttpServletRequest request, String nomChamp) {
        String valeur = request.getParameter(nomChamp);
        if (valeur == null || valeur.trim().length() == 0) {
            return null;
        } else {
            return valeur;
        }
    }
}
