package fr.ldnr.forms;

import fr.ldnr.beans.Utilisateur;
import fr.ldnr.dao.DAOFactory;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Herbert
 */
public class InscriptionCheckForm {

    private String resultat;
    private Map<String, String> erreurs = new HashMap<>();

    public String getResultat() {
        return resultat;
    }

    public Map<String, String> getErreurs() {
        return erreurs;
    }

    private void validationEmail(String email) throws Exception {
        if (email != null) {
            if (!email.matches("([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)")) {
                throw new Exception("Merci de saisir une adresse mail valide.");
            }
        } else {
            throw new Exception("Merci de saisir une adresse mail.");
        }
    }

    private void validationMotsDePasse(String motDePasse, String confirmation) throws Exception {
        if (motDePasse != null && confirmation != null) {
            if (!motDePasse.equals(confirmation)) {
                throw new Exception("Les mots de passe entrés sont différents, merci de les saisir à nouveau.");
            } else if (motDePasse.length() < 3) {
                throw new Exception("Les mots de passe doivent contenir au moins 3 caractères.");
            }
        } else {
            throw new Exception("Merci de saisir et confirmer votre mot de passe.");
        }
    }

    private void validationNom(String nom) throws Exception {
        if (nom != null && nom.length() < 3) {
            throw new Exception("Le nom d'utilisateur doit contenir au moins 3 caractères.");
        }
    }

    /*
     * Ajoute un message correspondant au champ spécifié à la map des erreurs.
     */
    private void setErreur(String champ, String message) {
        erreurs.put(champ, message);
    }

    /*
     * Méthode utilitaire qui retourne null si un champ est vide, et son contenu
     * sinon.
     */
    private static String getValeurChamp(HttpServletRequest request, String nomChamp) {
        String valeur = request.getParameter(nomChamp);
        if (valeur == null || valeur.trim().length() == 0) {
            return null;
        } else {
            return valeur.trim();
        }
    }

    /*
     * Méthode centrale de validation du formulaire
     */
    public Utilisateur checkForm(HttpServletRequest request) {
        String email = getValeurChamp(request, "email");
        String motDePasse = getValeurChamp(request, "motdepasse");
        String confirmation = getValeurChamp(request, "confirmation");
        String nom = getValeurChamp(request, "nom");

        Utilisateur utilisateur = new Utilisateur();

        try {
            validationEmail(email);
        } catch (Exception e) {
            setErreur("email", e.getMessage());
        }
        utilisateur.setEmail(email);

        try {
            validationMotsDePasse(motDePasse, confirmation);
        } catch (Exception e) {
            setErreur("motdepasse", e.getMessage());
            setErreur("confirmation", null);
        }
        utilisateur.setMotDePasse(motDePasse);

        try {
            validationNom(nom);
        } catch (Exception e) {
            setErreur("nom", e.getMessage());
        }
        utilisateur.setNom(nom);

        if (erreurs.isEmpty()) {
            resultat = "Succès de l'inscription.";
            // On persiste l'utilisateur en DB
            DAOFactory.getUtilisateurDAO().create(utilisateur);
            if (utilisateur.getId() == null) { // Pas d'id <=> pb de DB
                setErreur("email", "Un problème est survenu. Impossible de créer cet utilisateur.");
            }
        } else {
            resultat = "Échec de l'inscription.";
        }

        return utilisateur;
    }

}
